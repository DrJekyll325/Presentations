CREATE TABLE
	dbo.Choice
(
	ChoiceText		VARCHAR(1000) NOT NULL,
	ChoiceOrder		SMALLINT NOT NULL
)
AS EDGE;

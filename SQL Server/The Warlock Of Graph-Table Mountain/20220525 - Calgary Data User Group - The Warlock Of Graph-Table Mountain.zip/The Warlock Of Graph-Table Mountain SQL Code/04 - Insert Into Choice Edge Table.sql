TRUNCATE TABLE dbo.Choice;

INSERT INTO dbo.Choice VALUES ((SELECT $node_id FROM dbo.Section WHERE SectionID = 0), (SELECT $node_id FROM dbo.Section WHERE SectionID = 1), 
'Turn to 1.', 1);



INSERT INTO dbo.Choice VALUES ((SELECT $node_id FROM dbo.Section WHERE SectionID = 1), (SELECT $node_id FROM dbo.Section WHERE SectionID = 71), 
'Will you turn west (turn to 71)', 1);

INSERT INTO dbo.Choice VALUES ((SELECT $node_id FROM dbo.Section WHERE SectionID = 1), (SELECT $node_id FROM dbo.Section WHERE SectionID = 278), 
'or east (turn to 278)?', 2);



INSERT INTO dbo.Choice VALUES ((SELECT $node_id FROM dbo.Section WHERE SectionID = 2), (SELECT $node_id FROM dbo.Section WHERE SectionID = 16), 
'If you are Unlucky, you curse as you kick a small stone which goes skidding
across the cavern floor.  You draw your sword in case the Ogre has heard it -
turn to 16.', 1);

--INSERT INTO dbo.Choice VALUES ((SELECT $node_id FROM dbo.Section WHERE SectionID = 2), (SELECT $node_id FROM dbo.Section WHERE SectionID = 269), 
--'If you were Lucky, you creep down the corridor back to the crossroads.
--Turn to 269.', 2);



--INSERT INTO dbo.Choice VALUES ((SELECT $node_id FROM dbo.Section WHERE SectionID = 3), (SELECT $node_id FROM dbo.Section WHERE SectionID = 272), 
--'Do you pay him the 3 Gold Pieces (turn to 272)', 1);

--INSERT INTO dbo.Choice VALUES ((SELECT $node_id FROM dbo.Section WHERE SectionID = 3), (SELECT $node_id FROM dbo.Section WHERE SectionID = 127), 
--'or threaten him (turn to 127)?', 2);



INSERT INTO dbo.Choice VALUES ((SELECT $node_id FROM dbo.Section WHERE SectionID = 4), (SELECT $node_id FROM dbo.Section WHERE SectionID = 46), 
'To investigate, turn to 46.', 1);

--INSERT INTO dbo.Choice VALUES ((SELECT $node_id FROM dbo.Section WHERE SectionID = 4), (SELECT $node_id FROM dbo.Section WHERE SectionID = 332), 
--'To the south, the pass�ageway also turns east. Turn to 332 to go south.', 2);



--INSERT INTO dbo.Choice VALUES ((SELECT $node_id FROM dbo.Section WHERE SectionID = 5), (SELECT $node_id FROM dbo.Section WHERE SectionID = 97), 
--'Do you want to knock on the door and go in (turn to 97)', 1);

--INSERT INTO dbo.Choice VALUES ((SELECT $node_id FROM dbo.Section WHERE SectionID = 5), (SELECT $node_id FROM dbo.Section WHERE SectionID = 292), 
--'or will you continue northwards (turn to 292)?', 2);



--INSERT INTO dbo.Choice VALUES ((SELECT $node_id FROM dbo.Section WHERE SectionID = 6), (SELECT $node_id FROM dbo.Section WHERE SectionID = 89), 
--'Turn to 89.', 1);



--INSERT INTO dbo.Choice VALUES ((SELECT $node_id FROM dbo.Section WHERE SectionID = 7), (SELECT $node_id FROM dbo.Section WHERE SectionID = 214), 
--'Turn to 214.', 1);



--INSERT INTO dbo.Choice VALUES ((SELECT $node_id FROM dbo.Section WHERE SectionID = 8), (SELECT $node_id FROM dbo.Section WHERE SectionID = 189), 
--'There is a door in the north wall opposite, through which you may Escape during
--the battle (turn to 189).', 1);

--INSERT INTO dbo.Choice VALUES ((SELECT $node_id FROM dbo.Section WHERE SectionID = 8), (SELECT $node_id FROM dbo.Section WHERE SectionID = 273), 
--'If you defeat the Barbarian, turn to 273.', 2);



--INSERT INTO dbo.Choice VALUES ((SELECT $node_id FROM dbo.Section WHERE SectionID = 9), (SELECT $node_id FROM dbo.Section WHERE SectionID = 34), 
--'If you choose the tools, turn to 34.', 1);

--INSERT INTO dbo.Choice VALUES ((SELECT $node_id FROM dbo.Section WHERE SectionID = 9), (SELECT $node_id FROM dbo.Section WHERE SectionID = 322), 
--'If you choose the tools, turn to 34.  If you search the drawers, turn to 322.
--You hear a noise from behind the north door and realize you will have to
--hurry!', 2);



--INSERT INTO dbo.Choice VALUES ((SELECT $node_id FROM dbo.Section WHERE SectionID = 10), (SELECT $node_id FROM dbo.Section WHERE SectionID = 77), 
--'Turn to 77.', 1);



--INSERT INTO dbo.Choice VALUES ((SELECT $node_id FROM dbo.Section WHERE SectionID = 11), (SELECT $node_id FROM dbo.Section WHERE SectionID = 366), 
--'Then turn back up the passageway to the crossroads where you may go either
--northwards (turn to 366)', 1);

--INSERT INTO dbo.Choice VALUES ((SELECT $node_id FROM dbo.Section WHERE SectionID = 11), (SELECT $node_id FROM dbo.Section WHERE SectionID = 250), 
--'or southwards (turn to 250).', 2);



--INSERT INTO dbo.Choice VALUES ((SELECT $node_id FROM dbo.Section WHERE SectionID = 16), (SELECT $node_id FROM dbo.Section WHERE SectionID = 50), 
--'If you defeat him, turn to 50.', 1);

--INSERT INTO dbo.Choice VALUES ((SELECT $node_id FROM dbo.Section WHERE SectionID = 16), (SELECT $node_id FROM dbo.Section WHERE SectionID = 269), 
--'After the second Attack Round, you may Escape down the passage (turn to 269).', 2);



--INSERT INTO dbo.Choice VALUES ((SELECT $node_id FROM dbo.Section WHERE SectionID = 54), (SELECT $node_id FROM dbo.Section WHERE SectionID = 308), 
--'To go south, turn to 308.', 1);

--INSERT INTO dbo.Choice VALUES ((SELECT $node_id FROM dbo.Section WHERE SectionID = 54), (SELECT $node_id FROM dbo.Section WHERE SectionID = 179), 
--'To go through the door, turn to 179.', 2);



INSERT INTO dbo.Choice VALUES ((SELECT $node_id FROM dbo.Section WHERE SectionID = 71), (SELECT $node_id FROM dbo.Section WHERE SectionID = 301), 
'If you are Lucky, he does not wake up and remains snoring loudly - turn to 301.', 1);

--INSERT INTO dbo.Choice VALUES ((SELECT $node_id FROM dbo.Section WHERE SectionID = 71), (SELECT $node_id FROM dbo.Section WHERE SectionID = 248), 
--'If you are Unlucky, you step with a crunch on some loose ground and his eyes
--flick open - turn to 248.', 2);



INSERT INTO dbo.Choice VALUES ((SELECT $node_id FROM dbo.Section WHERE SectionID = 92), (SELECT $node_id FROM dbo.Section WHERE SectionID = 71), 
'Turn to 71.', 1);



INSERT INTO dbo.Choice VALUES ((SELECT $node_id FROM dbo.Section WHERE SectionID = 248), (SELECT $node_id FROM dbo.Section WHERE SectionID = 301), 
'If you defeat him, you may continue up the passage - turn to 301.', 1);



--INSERT INTO dbo.Choice VALUES ((SELECT $node_id FROM dbo.Section WHERE SectionID = 278), (SELECT $node_id FROM dbo.Section WHERE SectionID = 156), 
--'Will you try to charge the door down?  lf so, turn to 156.', 1);

--INSERT INTO dbo.Choice VALUES ((SELECT $node_id FROM dbo.Section WHERE SectionID = 278), (SELECT $node_id FROM dbo.Section WHERE SectionID = 92), 
--'If you would rather turn round and go back to the junction, turn to 92.', 2);



--INSERT INTO dbo.Choice VALUES ((SELECT $node_id FROM dbo.Section WHERE SectionID = 299), (SELECT $node_id FROM dbo.Section WHERE SectionID = 260), 
--'You may check for secret passages along the way (turn to 260)', 1);

--INSERT INTO dbo.Choice VALUES ((SELECT $node_id FROM dbo.Section WHERE SectionID = 299), (SELECT $node_id FROM dbo.Section WHERE SectionID = 359), 
--'or simply proceed northwards (turn to 359).', 2);



--INSERT INTO dbo.Choice VALUES ((SELECT $node_id FROM dbo.Section WHERE SectionID = 300), (SELECT $node_id FROM dbo.Section WHERE SectionID = 102), 
--'If you wish to try opening the door, turn to 102.', 1);

--INSERT INTO dbo.Choice VALUES ((SELECT $node_id FROM dbo.Section WHERE SectionID = 300), (SELECT $node_id FROM dbo.Section WHERE SectionID = 303), 
--'If you decide to ignore this room and continue up the corridor, turn to 303.', 2);



--INSERT INTO dbo.Choice VALUES ((SELECT $node_id FROM dbo.Section WHERE SectionID = 301), (SELECT $node_id FROM dbo.Section WHERE SectionID = 82), 
--'If so, turn to 82.', 1);

--INSERT INTO dbo.Choice VALUES ((SELECT $node_id FROM dbo.Section WHERE SectionID = 301), (SELECT $node_id FROM dbo.Section WHERE SectionID = 208), 
--'If you wish to press on northwards, turn to 208.', 2);

SELECT
	*
FROM
	dbo.Choice;

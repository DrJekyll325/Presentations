CREATE TABLE
	dbo.Section
(
	SectionID		INT PRIMARY KEY,
	SectionText		VARCHAR(4000) NOT NULL
)
AS NODE;

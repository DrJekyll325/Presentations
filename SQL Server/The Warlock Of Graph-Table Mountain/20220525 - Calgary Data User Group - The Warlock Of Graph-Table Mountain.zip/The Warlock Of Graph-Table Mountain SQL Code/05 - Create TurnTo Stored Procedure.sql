CREATE OR ALTER PROCEDURE dbo.TurnTo
(
	@SectionID	INT
)
AS
BEGIN

	DECLARE
		@CRLF			VARCHAR(2),
		@Description	VARCHAR(8000);

	SET @CRLF = CHAR(13) + CHAR(10);


	SELECT
		@Description = Sec.SectionText
	FROM
		dbo.Section Sec
	WHERE
		Sec.SectionID = @SectionID;


	SELECT
		@Description = @Description + @CRLF + @CRLF + Choice.ChoiceText
	FROM
		dbo.Section CurrentSection,
		dbo.Choice Choice,
		dbo.Section PossibleSection
	WHERE
		CurrentSection.SectionID = @SectionID
		AND
		MATCH (CurrentSection - (Choice) -> PossibleSection)
	ORDER BY
		Choice.ChoiceOrder;


	SELECT
		@Description;

END;

TRUNCATE TABLE dbo.Section;

INSERT INTO dbo.Section VALUES (0,
'Only a foolhardy adventurer would embark upon such a perilous quest without
first finding out as much as possible about the mountain and its treasures.
Before your arrival at the foot of Firetop Mountain, you spent several days with
the townsfolk of a local village some two days journey from the base.  Being a
likeable sort of person, you found it easy to get on with the local peasants.
Although they told many stories about the mysterious Warlock''s sanctuary, you
could not feel sure that all - or indeed any - of these were based on fact.  The
villagers had seen many adventurers pass through on their way to the mountain,
but very few ever returned.  The journey ahead was extremely dangerous, that you
knew for certain.  Of those who returned to the village, none contemplated going
back to Firetop Mountain.

There seemed to be some truth in the rumour that the Warlock''s treasure was
stored in a magnificent chest with two locks, and the keys to these locks were
guarded by various creatures within the dungeons.  The Warlock himself was a
sorcerer of great power.  Some described him as old, others as young.  Some said
his power came from an enchanted deck of cards, others from the silky black
gloves that he wore.

The entrance to the mountain was guarded by a pack of warty-faced Goblins,
stupid creatures, fond of their food and drink.  Towards the inner chambers, the
creatures became more fearsome.  To reach the inner chambers you would have to
cross a river.  The ferry service was regular, but the ferryman enjoyed a good
barter, so you should save a Gold Piece for the trip.  The locals also
encouraged you to keep a good map of your wanderings, for without a map you
would end up hopelessly lost within the mountain.
 
When it finally came to your day of leaving, the whole village turned out to
wish you a safe journey.  Tears came to the eyes of many of the women, young and
old alike.  You couldn''t help wondering whether they were tears of sorrow shed
by eyes which would never see you alive again...');


INSERT INTO dbo.Section VALUES (1,
'At last your two-day hike is over.  You unsheathe your sword, lay it on the
ground and sigh with relief as you lower yourself down on to the mossy rocks to
sit for a moment''s rest.  You stretch, rub your eyes and finally look up at
Firetop Mountain.

The very mountain itself looks menacing.  The steep face in front of you looks
to have been savaged by the claws of some gargantuan beast.  Sharp rocky crags
jut out at unnatural angles.  At the top of the mountain you can see the eerie
red colouring - probably some strange vegetation - which has given the mountain
its name.  Perhaps no one will ever know exactly what grows up there, as
climbing the peak must surely be impossible.

Your quest lies ahead of you.  Across the clearing is a dark cave entrance.  You
pick up your sword, get to your feet and consider what dangers may lie ahead of
you.  But with determination, you thrust the sword home into its scabbard and
approach the cave.

You peer into the gloom to see dark, slimy walls with pools of water on the
stone floor in front of you.  The air is cold and dank.  You light your lantern
and step warily into the blackness.  Cobwebs brush your face and you hear the
scurrying of tiny feet: rats, most likely.  You set off into the cave.  After a
few yards you arrive at a junction.');


INSERT INTO dbo.Section VALUES (2,
'Test your Luck.  If you are Lucky, you escape without attracting the Ogre''s
attention.');


INSERT INTO dbo.Section VALUES (3,
'The bell gives a dull clang and after a few moments you see a withered old man
climb into a small row�ing boat moored on the north bank.  He rows slowly across
to you, moors the boat and limps towards you.  He asks you for 3 Gold Pieces.
When you protest at the price he mumbles some flimsy excuse about ''inflation''.
He begins to get angry at your protestations.');


INSERT INTO dbo.Section VALUES (4,
'You find yourself in a north-south corridor.  To the north the passage turns
east some metres ahead.');


INSERT INTO dbo.Section VALUES (5,
'A rough timber doorway is on the east wall of the passage.  You listen at the
door and can hear a jolly sort of humming sound.');


INSERT INTO dbo.Section VALUES (6,
'The large solid door has no handle.  You charge it, but to no avail.  The door
is not going to budge.  You decide to give up and go through the opening you
passed in the east-west passageway some way back.');


INSERT INTO dbo.Section VALUES (7,
'You are on the north bank of a fast-flowing river in a large underground cavern.');


INSERT INTO dbo.Section VALUES (8,
'The passage ahead ends at a sturdy door.  You listen but hear nothing.  You try
the handle, it turns, and you enter the room.  As you look around you hear a
loud cry from behind you and swing round to see a wild man leaping towards you
wielding a large battle axe.  He is a mad BARBARIAN and you must fight him! 

BARBARIAN        SKILL 7        STAMINA 6');


INSERT INTO dbo.Section VALUES (9,
'Amazed at the success of your bluff, you decide to push your luck a little
further.  You can either examine the Skeletons'' tools or pretend you''re
look�ing for work-sheets and look through the drawers of the various benches.');


INSERT INTO dbo.Section VALUES (10,
'You arrive back at the junction and turn north�wards.');


INSERT INTO dbo.Section VALUES (11,
'You follow the passage westwards until it turns round a comer to the south.
Just before the bend is a signpost which reads ''Under Construction''.  In front
of you is the beginning of a stairway leading down�wards.  Only three steps have
been built so far.  A number of shovels, picks and other tools were lying on the
ground by the steps but, as you turned the corner, they suddenly flurried into
action and began working on the steps.  You are now watching various tools
digging and hammering as if being handled by invisible workers.  A humming chant
becomes louder and you recognize it as: ''Heigh-ho, Heigh-ho, It''s off to work
we go ...''  As you stand watching you start to chuckle - the scene is quite
amusing.  You sit and watch and even manage to chat to some of the magical
tools.  Gain 2 STAMINA points and 1 SKILL point whilst you relax.');


INSERT INTO dbo.Section VALUES (12,
'As you pull the knob, a deafening clanging noise rings through the passageways.
You frantically push the knob back to stop the alarm, but it has already had its
effect.  You can hear footsteps coming closer down the corridor.  Turn to 161 to
find what you have attracted.  Note down the number 12 so that you may return to
this section after fighting your battle.  When you have defeated this creature,
you may either return to the junction (turn to 256) or you may push the knob
(turn to 364).');


INSERT INTO dbo.Section VALUES (13,
'Your head hurts and you feel dizzy as you rise to your feet.  The four men stir
into action and move towards you in single file with their weapons ready.  You
grope your way down the wall for the south door but it will be touch and go
whether you make it.  Your foot slips on a loose pebble and you fall to the
ground. Before you can regain your footing, the creatures are upon you.  Turn to
282.');


INSERT INTO dbo.Section VALUES (14,
'There are no signs of any secret passages, but you suddenly hear footsteps
coming towards you.  To find out what is coming, turn to 161.  You must fight
this creature.  If you defeat the monster, turn to 117.  Note this reference so
you know where to return to.');


INSERT INTO dbo.Section VALUES (15,
'As you sit on the bench and eat your food, you begin to feel deeply relaxed and
the aches from your body� seem to be soothing themselves away.  This resting
place is enchanted.  You may restore 2 additional STAMINA points as well as the
normal amount (but only if this does not exceed your initial STAMINA score) and
restore 1 SKILL point if any have been lost.  When you are ready to continue,
move along the passage and turn to 367.');


INSERT INTO dbo.Section VALUES (16,
'You draw your sword, and as you do so the Ogre hears you and prepares to attack:

OGRE        SKILL 8        STAMINA 10');


INSERT INTO dbo.Section VALUES (17,
'Using the wooden stake and mallet (or makeshift mallet if you aren''t carrying
one), you form a cross and move towards the Vampire, backing it into a corner.
It hisses and snatches at you but cannot come near you.  However, it is going to
be tricky getting the stake through its heart.

As you advance, you stumble and fall forwards. As luck would have it, the stake
flies forward and plunges into the shrieking creature.  Test your Luck.  If you
are Lucky, the stake pierces the Vampire''s heart.  If you are Unlucky, the
Vampire is merely grazed by the wound (deduct 3 points from its STAMINA) and it
flings you backwards across the room towards the west door.  To Escape through
it, turn to 380.  To keep on fighting, tum to 144.  If you were Lucky and killed
the Vampire, you may look for its treasure - turn to 327.');


INSERT INTO dbo.Section VALUES (18,
'');


INSERT INTO dbo.Section VALUES (19,
'');


INSERT INTO dbo.Section VALUES (20,
'');


INSERT INTO dbo.Section VALUES (21,
'The green blood of the dead Orcs smells foul as it seeps from their bodies.  You
step around the corpses and investigate the chest.  It is a sturdy affair, made
of strong oak and iron, and it is firmly locked.  You may try to smash the lock
with your sword (turn to 339) or leave it alone and go through the open door
(turn to 293).');


INSERT INTO dbo.Section VALUES (22,
'You poke around looking for signs of secret doors but can find none. You pause
to ponder your situation and a small jet of gas hisses from the ceiling.  You
cough and choke to clear your lungs, but collapse to your knees.  Your head
spins and you flop to the floor in an unconscious heap.  When you come to, you
look around in an unfamiliar place.  Turn to 4.');


INSERT INTO dbo.Section VALUES (23,
'The passageway ends in a solid doorway and you are surprised to see a leather
skirt tacked along the bottom of the door.  You listen but hear nothing.  Will
you enter the room (turn to 326) or return to the junction (turn to 229)?');


INSERT INTO dbo.Section VALUES (24,
'');


INSERT INTO dbo.Section VALUES (25,
'');


INSERT INTO dbo.Section VALUES (26,
'');


INSERT INTO dbo.Section VALUES (27,
'');


INSERT INTO dbo.Section VALUES (28,
'The mighty Giant lies dead!  You search his cavern and find little of use,
although a purse in his belt contains 8 Gold Pieces.  You are a little concerned
about the second chair; to whom does it belong?  You decide to leave the cavern
the way you came.  Turn to 351.  But add2 LUCK and2 SKILL points for your
victory.');


INSERT INTO dbo.Section VALUES (29,
'Apart from the boots, which you decide to ignore, there appears to be little of
value in the cavern.  You decide to head back the way you came.  Turn to 375.');


INSERT INTO dbo.Section VALUES (30,
'A loose stone falls out to reveal a rope in the rock.  If you wish to pull it,
turn to 67.  If you feel it would be wiser to leave it alone, you can return to
the cross�roads (turn to 267).');


INSERT INTO dbo.Section VALUES (31,
'If you have the jewel from the Eye of the Cyclops, you hold it in front of the
Warlock.  His intimidating stare turns to an expression of pain.  He obviously
feels the jewel''s power.  Suddenly his eyes turn white and his expression goes
limp.  Your confi�dence gains as you realize you have won your first real battle.
Gain 2 SKILL points.  Put the jewel into your pack and leave through the north
door.  Turn to 90.');


INSERT INTO dbo.Section VALUES (32,
'');


INSERT INTO dbo.Section VALUES (33,
'');


INSERT INTO dbo.Section VALUES (34,
'');


INSERT INTO dbo.Section VALUES (35,
'As you step into the room, the door swings shut behind you.  As it closes, there
is a click and a hiss.  From the centre of the ceiling, a jet of gas is filling
the room with an acrid vapour.  You breathe and cough deeply.  You look at the
door and then the key.  Will you return to the door and escape quickly (turn to
136) or hold your breath and dash for the key first (turn to 361)?');


INSERT INTO dbo.Section VALUES (36,
'The locked door bursts open and a nauseating stench hits your nostrils.  Inside
the room the floor is covered with bones, rotting vegetation and slime.  A wild-
haired old man, clothed in rags, rushes at you screaming.  His beard is long and
grey, and he is waving an old wooden chair-leg.  Is he simply insane as he
appears, or has this been some kind of trap?  You may either shout at him to try
to calm him down (turn to 263) or draw your sword and attack him (tum to 353).');


INSERT INTO dbo.Section VALUES (37,
'Standing at the crossroads you may go either north (turn to 366), west (turn to
11) or south (turn to 277).');


INSERT INTO dbo.Section VALUES (44,
'Panting after the struggle, you sit down to collect yourself and finish the
Provisions you started.  Eventually you pack your bag and wade into the stream.
Turn to 399.');


INSERT INTO dbo.Section VALUES (45,
'The Cheese hits the portrait and bounces off.  You hear an evil laugh coming
from the walls andrealize the Warlock is mocking you.  You decide to leave the
room by the north door.  Turn to 90.');


INSERT INTO dbo.Section VALUES (46,
'You are standing in a short east-west passageway, with a door blocking the way
to the east.  To the west, the passage turns southwards after several metres.
To go round this bend turn to 4.  To go through the door, tum to 206.');


INSERT INTO dbo.Section VALUES (47,
'In the middle of the river, the bridge swings to and fro as it strains to take
your weight.  The handrail comes away suddenly as you lean on it.  Roll one die.
A roll of 6 sends you plunging into the river below� - turn to 158.  A roll of
1-5 means you regain your balance.  To go on, turn to 298.');


INSERT INTO dbo.Section VALUES (48,
'You are in an east-west corridor.  If you go east, you will turn a corner
northwards.  To go this way, turn to 391.  To go west, turn to 60.');


INSERT INTO dbo.Section VALUES (53,
'You charge the door, hitting it squarely with your shoulder.  Roll 2 dice.');


INSERT INTO dbo.Section VALUES (54,
'You are standing outside a door at the north end of a north-south passage.');


INSERT INTO dbo.Section VALUES (71,
'There is a right-hand turn to the north in the passage.  Cautiously you
approach a sentry post on the corner and, as you look in, you can see a strange
Goblin-like creature in leather armour asleep at his post.  You try to tiptoe
past him.  Test your Luck.');


INSERT INTO dbo.Section VALUES (92,
'You arrive back at the junction in the passage.  You look left to see the cave
entrance in the dim distance but walk straight on.');


INSERT INTO dbo.Section VALUES (248,
'The creature that has just awakened is an ORC!  He scrambles to his feet and
turns to grasp at a rope which is probably the alarm bell.  You must attack him
quickly. 

ORC        SKILL 6        STAMINA 5');


INSERT INTO dbo.Section VALUES (278,
'The passageway soon comes to an end at a locked wooden door.  You listen at the
door but hear nothing.  Will you try to charge the door down?');


INSERT INTO dbo.Section VALUES (299,
'The passageway runs east for several metres and then runs north.  You walk a
long way northwards.');


INSERT INTO dbo.Section VALUES (300,
'On the east wall of the passage you see another door, this time made of solid
metal.  Listening at the door you hear the sound of tortured screams coming from
within.');


INSERT INTO dbo.Section VALUES (301,
'To your left, on the west face of the passage, there is a rough-cut wooden door.
You listen at the door and can hear a rasping sound which may be some sort of
creature snoring.  Do you want to open the door?');


SELECT
	*
FROM
	dbo.Section;
